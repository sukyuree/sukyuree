package com.example.mobile_teamproject_startmenu;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import javax.security.auth.callback.CallbackHandler;

public class DisplayUserInformation extends AppCompatActivity {
    private DBHelper mydb;
    TextView name;
    TextView tall;
    TextView kg;
    TextView fatrate;
    TextView disease;
    int id = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.startmenu);

        name = (TextView) findViewById(R.id.ent_name);
        tall = (TextView) findViewById(R.id.ent_tall);
        kg = (TextView) findViewById(R.id.ent_kg);
        fatrate = (TextView) findViewById(R.id.ent_fatrate);
        disease = (TextView) findViewById(R.id.ent_disease);

        mydb = new DBHelper(this);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            int Value = extras.getInt("id");
            if(Value > 0) {
                Cursor rs = mydb.getData(Value);
                id = Value;
                rs.moveToFirst();
                String n = rs.getString(rs.getColumnIndex(DBHelper.USERNAME));
                String t = rs.getString(rs.getColumnIndex(DBHelper.USERTALL));
                String k = rs.getString(rs.getColumnIndex(DBHelper.USERKG));
                String f = rs.getString(rs.getColumnIndex(DBHelper.USERFATLATE));
                String d = rs.getString(rs.getColumnIndex(DBHelper.USERDISEASE));

                if(!rs.isClosed()) {
                    rs.close();
                }


                name.setText((CharSequence) n);
                tall.setText((CharSequence) t);
                kg.setText((CharSequence) k);
                fatrate.setText((CharSequence) f);
                disease.setText((CharSequence) d);
            }
        }
    }

    public void insert(View view) {
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            int Value = extras.getInt("id");
            if(Value > 0) {
                if(mydb.updateUserInformation(id, name.getText().toString(), tall.getText().toString(),
                        kg.getText().toString(),fatrate.getText().toString(), disease.getText().toString() )) {
                    Toast.makeText(getApplicationContext(), "수정되었음", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(getApplicationContext(), com.example.mobile_teamproject_startmenu.MainActivity.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(getApplicationContext(), "수정되지 않았음", Toast.LENGTH_SHORT).show();
                }
            } else {
                if(mydb.insertUser(name.getText().toString(), kg.getText().toString(), tall.getText().toString(),
                        fatrate.getText().toString(), disease.getText().toString())); {
                            Toast.makeText(getApplicationContext(), "추가되지 않았음", Toast.LENGTH_SHORT).show();
                }
                finish();
            }
        }
    }

    public void delete(View view) {
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            int Value = extras.getInt("id");
            if ( Value > 0) {
                mydb.deleteUserInformation(id);
                Toast.makeText(getApplicationContext(), "삭제되었음", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(getApplicationContext(), "삭제되지 않았음", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void edit(View view) {
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            int Value = extras.getInt("id");
            if( Value > 0) {
                if(mydb.updateUserInformation(id, name.getText().toString(), tall.getText().toString(), kg.getText().toString(),
                        fatrate.getText().toString(), disease.getText().toString())) {
                    Toast.makeText(getApplicationContext(), "수정되었음", Toast.LENGTH_SHORT).show();
                    finish();
                } else {
                    Toast.makeText(getApplicationContext(), " 수정되지 않았음", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }
}