package com.example.mobile_teamproject_startmenu;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class DBHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "UserInformation.db";
    public static final int DATABASE_VERSION = 2;
    public static final String TABLE_NAME = "UserInformation";
    public static final String USER_ID = "id";
    public static final String USERNAME = "name";
    public static final String USERTALL = "tall";
    public static final String USERKG = "kg";
    public static final String USERFATLATE = "fatrate";
    public static final String USERDISEASE = "disease";

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null,  DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE UserInformation" + "(id integer primary key, name text, tall text, kg text, fatrate text, disease text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS UserInformation");
        onCreate(db);
    }

    public boolean insertUser(String name, String kg, String tall, String fatrate, String disease) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put("name", name);
        contentValues.put("tall", tall);
        contentValues.put("kg", kg);
        contentValues.put("fatrate", fatrate);
        contentValues.put("disease", disease);

        db.insert("UserInformation",null, contentValues);

        return true;
    }

    public Cursor getData(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from UserInformation where id = " + id + "", null);
        return res;
    }

    public int numberOfRows() {
        SQLiteDatabase db = this.getReadableDatabase();
        int numRows = (int) DatabaseUtils.queryNumEntries(db,TABLE_NAME);
        return numRows;
    }

    public boolean updateUserInformation(Integer id, String name, String tall, String kg, String fatrate, String disease) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues contentValues =new ContentValues();
        contentValues.put("name", name);
        contentValues.put("tall", tall);
        contentValues.put("kg", kg);
        contentValues.put("fatrate", fatrate);
        contentValues.put("disease", disease);
        db.update("UserInformation", contentValues, "id = ?", new String[]{Integer.toString(id)});

        return true;
    }

    public Integer deleteUserInformation(Integer id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete("Userinformation", "id = ?", new String[] {Integer.toString(id)});
    }

    public ArrayList getUserInformation() {
        ArrayList array_list = new ArrayList();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res =db.rawQuery("select * from UserInformation", null);
        res.moveToFirst();

        return array_list;
    }

}
